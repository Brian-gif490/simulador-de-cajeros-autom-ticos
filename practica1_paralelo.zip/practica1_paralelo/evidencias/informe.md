# Informe de despliegue local — Sistema de Gestión de Papelería

- **Fecha de verificación:** 2026-11-05 10:58 (-04:00)
- **Proyecto:** Sistema de Gestión de Productos y Ventas — Papelería
- **Directorio de despliegue:** `/home/firnt/Música/practica2_paralelo/practica ` (la carpeta tiene un espacio final en su nombre)
- **Archivo de orquestación:** `docker-compose.yml`
- **Logs completos:** [`docker-logs.txt`](./docker-logs.txt)

> Nota: el `docker-compose.yml` no está en el directorio padre `practica2_paralelo`, sino dentro de la subcarpeta `practica `.

---

## 1. Configuración de Docker Compose

| Servicio | Contenedor | Imagen / Build | Puerto host → contenedor | Estado |
|---|---|---|---|---|
| `postgres-db` | `papeleria_postgres_db` | `postgres:15-alpine` | **5435 → 5432** | Up (healthy) |
| `backend-api` | `papeleria_backend_api` | `./backend` | **5002 → 5000** | Up |
| `frontend-app` | `papeleria_frontend_app` | `./frontend` | **5175 → 5173** | Up |

- **Red:** `practica_papeleria_network` (driver `bridge`).
- **Volumen:** `practica_postgres_data` → `/var/lib/postgresql/data`.
- **Healthcheck de PostgreSQL:** `pg_isready -U admin_papeleria -d papeleria_db` cada 5 s.
- **Dependencias:** `backend-api` espera a que `postgres-db` esté `healthy`; `frontend-app` depende de `backend-api`.
- **Comando backend:** `npx prisma generate && npm run dev` (nodemon + tsx).
- **Comando frontend:** `npm run dev -- --host` (Vite).

### Variables de entorno relevantes (`.env`)

| Variable | Valor |
|---|---|
| `DATABASE_URL` | `postgresql://admin_papeleria:********@postgres-db:5432/papeleria_db?schema=public` |
| `PORT` | `5000` |
| `FRONTEND_URL` | `http://localhost:5175` |
| `VITE_API_URL` | `http://localhost:5002/api` |
| `NODE_ENV` | `development` |
| `JWT_EXPIRES_IN` | `8h` |
| `JWT_SECRET` | Configurado (valor no expuesto en este informe) |

---

## 2. Estado de los contenedores Docker

Salida de `docker compose ps`:

```
NAME                     SERVICE        STATUS                    PORTS
papeleria_backend_api    backend-api    Up 24 minutes             0.0.0.0:5002->5000/tcp, [::]:5002->5000/tcp
papeleria_frontend_app   frontend-app   Up 24 minutes             0.0.0.0:5175->5173/tcp, [::]:5175->5173/tcp
papeleria_postgres_db    postgres-db    Up 24 minutes (healthy)   0.0.0.0:5435->5432/tcp, [::]:5435->5432/tcp
```

- Los tres contenedores están **activos**.
- `postgres-db` se encuentra **healthy**.
- Los puertos publicados en el host son **5435, 5002 y 5175**.
- No existen conflictos de puertos: el puerto estándar 5173 está ocupado por otro proyecto (`restaurante_frontend`), pero este stack usa **5175**. Los puertos 5435, 5002 y 5175 están escuchando correctamente en el host.

---

## 3. Verificación en caliente de rutas HTTP

| Método | Ruta | Código HTTP | Resultado |
|---|---|---|---|
| GET | `http://localhost:5175/` | **200** | Frontend Vite responde y sirve el HTML con `<div id="root">`. |
| GET | `http://localhost:5002/` | **200** | Backend identifica el proyecto. |
| GET | `http://localhost:5002/api/health` | **200** | Health check del API correcto. |
| POST | `http://localhost:5002/api/auth/login` | **200** | Login exitoso; emite token JWT para el rol Administrador. |
| GET | `http://localhost:5002/api/auth/me` | **200** | Devuelve el usuario autenticado (`Administrador General`). |
| GET | `http://localhost:5002/api/productos` | **200** | Devuelve el catálogo (22 productos). |
| GET | `http://localhost:5002/api/categorias` | **200** | Devuelve las categorías registradas. |
| GET | `http://localhost:5002/api/dashboard/resumen` | **200** | Devuelve métricas del dashboard (productos, ventas, ingresos). |
| GET | `http://localhost:5002/api/categorias` sin token | **401** | La protección JWT funciona correctamente. |
| OPTIONS | `http://localhost:5002/api/auth/login` con `Origin: http://localhost:5175` | **204** | CORS permite el origen del frontend y credenciales. |
| GET | `http://localhost:5175/api/health` (proxy Vite) | **404** | Hallazgo: el proxy reescribe `/api` y el backend responde `Ruta no encontrada: /health`. |

**Credenciales de prueba utilizadas:** `admin.papeleria@empresa.com` / `Papeleria2026*` (datos del seed).

### Observación sobre el proxy de Vite

En `frontend/vite.config.ts` el proxy define:

```ts
rewrite: (path) => path.replace(/^\/api/, ''),
```

Esto elimina el prefijo `/api`, pero el backend expone todas sus rutas con ese prefijo. Por ello, `http://localhost:5175/api/health` responde **404**. La aplicación no se ve afectada actualmente porque el frontend consume el backend mediante `VITE_API_URL=http://localhost:5002/api` (URL absoluta), pero el proxy debería corregirse (quitar el `rewrite`) si se desea usar a través de Vite.

---

## 4. Migraciones de Prisma

Comando ejecutado:

```bash
docker compose exec -T backend-api npx prisma migrate status
```

Resultado:

```
Datasource "db": PostgreSQL database "papeleria_db", schema "public" at "postgres-db:5432"

1 migration found in prisma/migrations

Database schema is up to date!
```

Migración aplicada registrada en `_prisma_migrations`:

| Migración | Fecha de aplicación |
|---|---|
| `20260922002921_init` | 2026-11-03 15:23:37.364861+00 |

Tablas creadas y verificadas en PostgreSQL:

`_prisma_migrations`, `roles`, `usuarios`, `clientes`, `categorias`, `productos`, `ventas`, `detalle_ventas`.

> El servicio `backend-api` no ejecuta `prisma migrate deploy` al arrancar; solo ejecuta `prisma generate`. Las migraciones están aplicadas porque el volumen `practica_postgres_data` ya contenía el esquema. En un volumen limpio sería necesario ejecutar `npx prisma migrate deploy` (y opcionalmente el seed) manualmente o añadirlo al comando/entrypoint.

---

## 5. Datos iniciales (seed)

Conteo actual en la base de datos `papeleria_db`:

| Tabla | Registros |
|---|---|
| `usuarios` | 3 |
| `categorias` | 7 |
| `productos` | 22 |
| `clientes` | 4 |
| `ventas` | 3 |
| `detalle_ventas` | 8 |

Usuarios del seed:

| ID | Nombre | Correo | Activo |
|---|---|---|---|
| 1 | Administrador General | `admin.papeleria@empresa.com` | Sí |
| 2 | Carlos Mamani | `vendedor1.papeleria@empresa.com` | Sí |
| 3 | María Rojas | `vendedor2.papeleria@empresa.com` | Sí |

La contraseña por defecto del seed es `Papeleria2026*`.

---

## 6. Logros clave de los logs

**Backend (`papeleria_backend_api`):**

```
Loaded Prisma config from prisma.config.ts.
Prisma schema loaded from prisma/schema.prisma.
✔ Generated Prisma Client (v7.10.1) to ./node_modules/@prisma/client in 69ms
[nodemon] 3.1.14
[nodemon] starting `tsx src/server.ts`
🚀 Servidor de Gestión de Papelería corriendo en el puerto 5000 bajo TypeScript.
```

**Frontend (`papeleria_frontend_app`):**

```
VITE v5.4.21 ready in 124 ms
➜ Local: http://localhost:5173/
➜ Network: http://172.19.0.4:5173/
```

**PostgreSQL (`papeleria_postgres_db`):**

```
PostgreSQL Database directory appears to contain a database; Skipping initialization
starting PostgreSQL 15.19 on x86_64-pc-linux-musl
listening on IPv4 address "0.0.0.0", port 5432
database system is ready to accept connections
```

Los únicos mensajes `ERROR` presentes en el historial de logs de PostgreSQL corresponden a ejecuciones antiguas del 2026-11-03 (antes de aplicar las migraciones) y no al despliegue actual.

---

## 7. Conclusión

El despliegue local quedó **plenamente operativo**:

- Frontend accesible en **http://localhost:5175** (HTTP 200).
- Backend/API accesible en **http://localhost:5002** con health check en **HTTP 200**.
- PostgreSQL accesible en **localhost:5435**, estado **healthy**.
- Prisma conectado correctamente a PostgreSQL y esquema **up to date**.
- Autenticación JWT y rutas protegidas funcionando.
- Datos iniciales (seed) presentes: 3 usuarios, 7 categorías, 22 productos, 4 clientes, 3 ventas y 8 detalles de venta.
- CORS habilitado para el frontend en `http://localhost:5175`.
- Logs completos guardados en `evidencias/docker-logs.txt`.

**Recomendaciones:**

1. Corregir el `rewrite` del proxy en `frontend/vite.config.ts` para conservar el prefijo `/api`.
2. Añadir `npx prisma migrate deploy` (y opcionalmente el seed) al arranque del backend para despliegues con volumen limpio.
3. Considerar añadir healthchecks explícitos para `backend-api` y `frontend-app`.
