// src/views/login/LoginView.tsx
import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';

export const LoginView: React.FC = () => {
  const { login } = useAuth();
  const navigate = useNavigate();

  const [correo, setCorreo] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorInfo, setErrorInfo] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return;

    setErrorInfo(null);
    setSubmitting(true);

    try {
      await login(correo, password);
      navigate('/dashboard', { replace: true });
    } catch (err: any) {
      setErrorInfo(err.message || 'Error de autenticación. Intente nuevamente.');
      setSubmitting(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-950 p-4">
      <div className="w-full max-w-md space-y-6 rounded-2xl bg-gray-900 p-8 shadow-2xl border border-gray-800">
        <div className="text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-xl bg-blue-600 text-2xl">
            🖊️
          </div>
          <h2 className="text-2xl font-extrabold tracking-tight text-white">Papelería</h2>
          <p className="mt-1 text-sm text-gray-400">Sistema de gestión de productos y ventas</p>
        </div>

        <form className="space-y-4" onSubmit={handleSubmit}>
          {errorInfo && (
            <div className="rounded-lg bg-red-500/10 p-3 border border-red-500/20 text-center text-sm font-medium text-red-400">
              {errorInfo}
            </div>
          )}

          <div className="flex flex-col">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">
              Correo
            </label>
            <input
              type="email"
              required
              value={correo}
              onChange={(e) => setCorreo(e.target.value)}
              className="w-full rounded-lg bg-gray-800 border border-gray-700 px-4 py-3 text-white placeholder-gray-500 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 transition-colors"
              placeholder="usuario@empresa.com"
            />
          </div>

          <div className="flex flex-col">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">
              Contraseña
            </label>
            <div className="relative w-full">
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-lg bg-gray-800 border border-gray-700 pl-4 pr-12 py-3 text-white placeholder-gray-500 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 transition-colors"
                placeholder="••••••••"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white transition-colors p-1 cursor-pointer"
                title={showPassword ? 'Ocultar contraseña' : 'Mostrar contraseña'}
              >
                {showPassword ? '🙈' : '👁️'}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full flex justify-center rounded-lg bg-blue-600 px-4 py-3 text-sm font-semibold text-white hover:bg-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 focus:ring-offset-gray-900 disabled:opacity-50 transition-all cursor-pointer shadow-lg shadow-blue-600/20"
          >
            {submitting ? 'Iniciando sesión...' : 'Ingresar'}
          </button>
        </form>

        <div className="rounded-lg bg-gray-800/60 p-3 text-xs text-gray-400 border border-gray-700">
          <p className="font-semibold text-gray-300 mb-1">Credenciales de prueba</p>
          <p>Admin: admin.papeleria@empresa.com / Papeleria2026*</p>
          <p>Vendedor: vendedor1.papeleria@empresa.com / Papeleria2026*</p>
        </div>
      </div>
    </div>
  );
};