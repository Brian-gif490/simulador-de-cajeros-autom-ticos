// src/views/DashboardView.tsx
import React, { useCallback, useEffect, useState } from 'react';
import { obtenerResumen } from '../services/ventas.service';
import { extraerMensajeError } from '../services/httpClient';
import { ResumenDashboard } from '../interfaces/entidades';

const formatoBs = (n: number) =>
  `Bs ${n.toLocaleString('es-BO', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

export const DashboardView: React.FC = () => {
  const [resumen, setResumen] = useState<ResumenDashboard | null>(null);
  const [error, setError] = useState<string | null>(null);

  const cargar = useCallback(async () => {
    setError(null);
    try {
      setResumen(await obtenerResumen());
    } catch (err: any) {
      setError(extraerMensajeError(err));
    }
  }, []);

  useEffect(() => {
    cargar();
  }, [cargar]);

  const tarjetas = resumen
    ? [
        { label: 'Productos activos', valor: String(resumen.productosActivos), color: 'blue' },
        { label: 'Productos con stock bajo', valor: String(resumen.stockBajo), color: 'amber' },
        { label: 'Ventas de hoy', valor: String(resumen.ventasHoy), color: 'green' },
        { label: 'Ingresos de hoy', valor: formatoBs(resumen.ingresosHoy), color: 'blue' },
        { label: 'Ingresos totales', valor: formatoBs(resumen.ingresosTotales), color: 'green' },
        { label: 'Ventas registradas', valor: String(resumen.ventas), color: 'gray' },
      ]
    : [];

  const colores: Record<string, string> = {
    blue: 'from-blue-600 to-blue-500',
    amber: 'from-amber-500 to-orange-500',
    green: 'from-emerald-600 to-emerald-500',
    gray: 'from-gray-700 to-gray-600',
  };

  return (
    <div>
      <h1 className="text-2xl font-bold text-white mb-6">Panel de control</h1>

      {error && (
        <div className="mb-4 rounded-lg bg-red-500/10 border border-red-500/20 p-3 text-sm text-red-400">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {tarjetas.map((t) => (
          <div key={t.label} className={`rounded-2xl bg-gradient-to-br ${colores[t.color]} p-5 text-white shadow-lg`}>
            <p className="text-xs font-medium uppercase tracking-wider opacity-80">{t.label}</p>
            <p className="mt-2 text-3xl font-bold">{t.valor}</p>
          </div>
        ))}
      </div>

      <h2 className="text-lg font-semibold text-white mb-3">Últimas ventas</h2>
      <div className="rounded-xl bg-gray-900 border border-gray-800 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-800/60 text-left text-xs uppercase tracking-wider text-gray-400">
            <tr>
              <th className="px-4 py-3">Código</th>
              <th className="px-4 py-3">Fecha</th>
              <th className="px-4 py-3">Cliente</th>
              <th className="px-4 py-3">Vendedor</th>
              <th className="px-4 py-3 text-right">Total</th>
              <th className="px-4 py-3">Estado</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-800">
            {resumen?.ultimasVentas.map((v) => (
              <tr key={v.id}>
                <td className="px-4 py-3 font-medium">{v.codigo}</td>
                <td className="px-4 py-3 text-gray-400">{new Date(v.fecha).toLocaleString('es-BO')}</td>
                <td className="px-4 py-3">{v.cliente?.nombre || '—'}</td>
                <td className="px-4 py-3">{v.usuario?.nombre || '—'}</td>
                <td className="px-4 py-3 text-right font-semibold">{formatoBs(Number(v.total))}</td>
                <td className="px-4 py-3">
                  <span
                    className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                      v.estado === 'COMPLETADA'
                        ? 'bg-emerald-500/10 text-emerald-400'
                        : 'bg-red-500/10 text-red-400'
                    }`}
                  >
                    {v.estado === 'COMPLETADA' ? 'Completada' : 'Anulada'}
                  </span>
                </td>
              </tr>
            ))}
            {resumen && resumen.ultimasVentas.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-8 text-center text-gray-500">
                  Aún no hay ventas registradas.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};