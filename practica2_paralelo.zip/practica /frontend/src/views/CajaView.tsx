// src/views/CajaView.tsx
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Plus, Trash2, Undo2, ShoppingCart } from 'lucide-react';
import { listarProductos } from '../services/productos.service';
import { listarClientes, crearCliente } from '../services/catalogos.service';
import { registrarVenta, listarVentas, anularVenta } from '../services/ventas.service';
import { extraerMensajeError } from '../services/httpClient';
import { Cliente, Producto, Venta } from '../interfaces/entidades';

const formatoBs = (n: number | string) =>
  `Bs ${Number(n).toLocaleString('es-BO', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

const hoyLocal = () => new Date().toISOString().slice(0, 10);

interface ItemLinea {
  productoId: number;
  nombre: string;
  codigo: string;
  cantidad: number;
  precio: number;
}

export const CajaView: React.FC = () => {
  const [productos, setProductos] = useState<Producto[]>([]);
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [ventas, setVentas] = useState<Venta[]>([]);

  // Formulario de registro
  const [clienteId, setClienteId] = useState<number>(0);
  const [mostrarNuevoCliente, setMostrarNuevoCliente] = useState(false);
  const [nuevoClienteNombre, setNuevoClienteNombre] = useState('');
  const [nuevoClienteNit, setNuevoClienteNit] = useState('');
  const [productoFiltro, setProductoFiltro] = useState('');
  const [productoId, setProductoId] = useState<number>(0);
  const [cantidad, setCantidad] = useState(1);
  const [lineas, setLineas] = useState<ItemLinea[]>([]);
  const [descuento, setDescuento] = useState(0);

  // Filtros del cuaderno
  const [desde, setDesde] = useState(hoyLocal());
  const [hasta, setHasta] = useState(hoyLocal());

  const [mensaje, setMensaje] = useState<string | null>(null);
  const [guardando, setGuardando] = useState(false);

  const cargar = useCallback(async () => {
    try {
      const [prods, clis] = await Promise.all([listarProductos(), listarClientes()]);
      setProductos(prods);
      setClientes(clis);
    } catch (err: any) {
      setMensaje(extraerMensajeError(err));
    }
  }, []);

  const cargarVentas = useCallback(async (d: string, h: string) => {
    try {
      setVentas(await listarVentas({ desde: d, hasta: h }));
    } catch (err: any) {
      setMensaje(extraerMensajeError(err));
    }
  }, []);

  useEffect(() => {
    cargar();
  }, [cargar]);

  useEffect(() => {
    cargarVentas(desde, hasta);
  }, [desde, hasta, cargarVentas]);

  const productosFiltrados = useMemo(() => {
    const term = productoFiltro.toLowerCase().trim();
    const disponibles = productos.filter((p) => p.stock > 0);
    if (!term) return disponibles;
    return disponibles.filter(
      (p) => p.nombre.toLowerCase().includes(term) || p.codigo.toLowerCase().includes(term)
    );
  }, [productos, productoFiltro]);

  const productoSeleccionado = productos.find((p) => p.id === Number(productoId));

  const agregarLinea = () => {
    const prod = productos.find((p) => p.id === Number(productoId));
    if (!prod || cantidad <= 0) return;
    setLineas((prev) => {
      const existente = prev.find((l) => l.productoId === prod.id);
      if (existente) {
        return prev.map((l) =>
          l.productoId === prod.id
            ? { ...l, cantidad: l.cantidad + cantidad, precio: Number(prod.precioVenta) }
            : l
        );
      }
      return [
        ...prev,
        {
          productoId: prod.id,
          nombre: prod.nombre,
          codigo: prod.codigo,
          cantidad,
          precio: Number(prod.precioVenta),
        },
      ];
    });
    setCantidad(1);
    setProductoId(0);
  };

  const quitarLinea = (productoId: number) =>
    setLineas((prev) => prev.filter((l) => l.productoId !== productoId));

  const subtotal = lineas.reduce((acc, l) => acc + l.precio * l.cantidad, 0);
  const total = Math.max(0, subtotal - Number(descuento) || 0);

  const registrar = async (e: React.FormEvent) => {
    e.preventDefault();
    if (lineas.length === 0) {
      setMensaje('Agregue al menos un producto a la venta.');
      return;
    }
    setGuardando(true);
    setMensaje(null);
    try {
      let clienteFinal = clienteId ? Number(clienteId) : undefined;
      if (mostrarNuevoCliente && nuevoClienteNombre.trim()) {
        const nuevo = await crearCliente({
          nombre: nuevoClienteNombre.trim(),
          nit: nuevoClienteNit.trim() || undefined,
        });
        clienteFinal = nuevo.id;
        setClientes((prev) => [...prev, nuevo]);
      }

      await registrarVenta({
        clienteId: clienteFinal,
        descuento: Number(descuento) || 0,
        items: lineas.map((l) => ({ productoId: l.productoId, cantidad: l.cantidad })),
      });

      setMensaje(`Venta registrada correctamente. Total: ${formatoBs(total)}`);
      setLineas([]);
      setDescuento(0);
      setClienteId(0);
      setMostrarNuevoCliente(false);
      setNuevoClienteNombre('');
      setNuevoClienteNit('');
      await Promise.all([cargar(), cargarVentas(desde, hasta)]);
    } catch (err: any) {
      setMensaje(extraerMensajeError(err));
    } finally {
      setGuardando(false);
    }
  };

  const anular = async (v: Venta) => {
    if (!window.confirm(`¿Anular la venta ${v.codigo} por ${formatoBs(v.total)}? Se repondrá el stock.`)) return;
    setMensaje(null);
    try {
      await anularVenta(v.id);
      setMensaje(`Venta ${v.codigo} anulada.`);
      await Promise.all([cargar(), cargarVentas(desde, hasta)]);
    } catch (err: any) {
      setMensaje(extraerMensajeError(err));
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-bold text-white mb-6">Caja y Ventas</h1>

      {mensaje && (
        <div
          className={`mb-4 rounded-lg border p-3 text-sm ${
            mensaje.startsWith('Venta') || mensaje.startsWith('Bs')
              ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
              : 'bg-red-500/10 border-red-500/20 text-red-400'
          }`}
        >
          {mensaje}
        </div>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* ============================================================
             FORMULARIO DE REGISTRO DE VENTA
        ============================================================ */}
        <div className="rounded-2xl bg-gray-900 border border-gray-800 p-6">
          <div className="flex items-center gap-2 mb-4">
            <ShoppingCart className="h-5 w-5 text-blue-400" />
            <h2 className="text-lg font-semibold text-white">Registrar venta</h2>
          </div>

          <form onSubmit={registrar} className="space-y-4">
            {/* Cliente */}
            <div className="flex flex-col">
              <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">
                Cliente
              </label>
              {!mostrarNuevoCliente ? (
                <select
                  value={clienteId}
                  onChange={(e) => setClienteId(Number(e.target.value))}
                  className="rounded-lg bg-gray-800 border border-gray-700 px-3 py-2 text-sm text-white focus:border-blue-500 focus:outline-none"
                >
                  <option value={0}>Sin cliente (venta al mostrador)</option>
                  {clientes.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.nombre}
                    </option>
                  ))}
                </select>
              ) : (
                <div className="flex flex-col gap-2">
                  <input
                    value={nuevoClienteNombre}
                    onChange={(e) => setNuevoClienteNombre(e.target.value)}
                    placeholder="Nombre del nuevo cliente"
                    className="rounded-lg bg-gray-800 border border-gray-700 px-3 py-2 text-sm text-white focus:border-blue-500 focus:outline-none"
                  />
                  <input
                    value={nuevoClienteNit}
                    onChange={(e) => setNuevoClienteNit(e.target.value)}
                    placeholder="NIT (opcional)"
                    className="rounded-lg bg-gray-800 border border-gray-700 px-3 py-2 text-sm text-white focus:border-blue-500 focus:outline-none"
                  />
                </div>
              )}
              <button
                type="button"
                onClick={() => setMostrarNuevoCliente((v) => !v)}
                className="self-start mt-1 text-xs text-blue-400 hover:text-blue-300 transition-colors cursor-pointer"
              >
                {mostrarNuevoCliente ? '← Elegir cliente existente' : '+ Registrar nuevo cliente'}
              </button>
            </div>

            {/* Agregar productos */}
            <div className="flex flex-col">
              <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">
                Producto
              </label>
              <input
                value={productoFiltro}
                onChange={(e) => setProductoFiltro(e.target.value)}
                placeholder="Buscar producto disponible..."
                className="rounded-lg bg-gray-800 border border-gray-700 px-3 py-2 text-sm text-white mb-2 focus:border-blue-500 focus:outline-none"
              />
              <select
                value={productoId}
                onChange={(e) => setProductoId(Number(e.target.value))}
                className="rounded-lg bg-gray-800 border border-gray-700 px-3 py-2 text-sm text-white focus:border-blue-500 focus:outline-none"
              >
                <option value={0} disabled>
                  Seleccione un producto...
                </option>
                {productosFiltrados.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.nombre} — {p.codigo} (stock: {p.stock})
                  </option>
                ))}
              </select>
            </div>

            <div className="flex gap-3">
              <div className="flex flex-col flex-1">
                <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">
                  Cantidad
                </label>
                <input
                  type="number"
                  min={1}
                  max={productoSeleccionado?.stock ?? 1}
                  value={cantidad}
                  onChange={(e) => setCantidad(Math.max(1, Number(e.target.value)))}
                  className="rounded-lg bg-gray-800 border border-gray-700 px-3 py-2 text-sm text-white focus:border-blue-500 focus:outline-none"
                />
              </div>
              <button
                type="button"
                onClick={agregarLinea}
                className="flex items-center gap-2 self-end rounded-lg bg-gray-700 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-600 transition-colors cursor-pointer"
              >
                <Plus className="h-4 w-4" />
                Agregar
              </button>
            </div>

            {/* Líneas de la venta */}
            <div className="rounded-lg bg-gray-800/50 border border-gray-700 overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-gray-800 text-left text-xs uppercase tracking-wider text-gray-400">
                  <tr>
                    <th className="px-3 py-2">Producto</th>
                    <th className="px-3 py-2 text-center">Cant.</th>
                    <th className="px-3 py-2 text-right">Total</th>
                    <th className="px-3 py-2"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-700">
                  {lineas.map((l) => (
                    <tr key={l.productoId}>
                      <td className="px-3 py-2">
                        {l.nombre}
                        <span className="block text-xs text-gray-500">{l.codigo}</span>
                      </td>
                      <td className="px-3 py-2 text-center">{l.cantidad}</td>
                      <td className="px-3 py-2 text-right font-medium">
                        {formatoBs(l.precio * l.cantidad)}
                      </td>
                      <td className="px-3 py-2 text-right">
                        <button
                          type="button"
                          onClick={() => quitarLinea(l.productoId)}
                          className="rounded p-1 text-gray-500 hover:text-red-400 transition-colors cursor-pointer"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {lineas.length === 0 && (
                    <tr>
                      <td colSpan={4} className="px-3 py-4 text-center text-gray-500">
                        Sin productos agregados.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <div className="flex flex-col">
              <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">
                Descuento (Bs)
              </label>
              <input
                type="number"
                min={0}
                step="0.01"
                value={descuento}
                onChange={(e) => setDescuento(Number(e.target.value))}
                className="rounded-lg bg-gray-800 border border-gray-700 px-3 py-2 text-sm text-white focus:border-blue-500 focus:outline-none"
              />
            </div>

            <div className="flex items-center justify-between rounded-lg bg-gray-800/60 border border-gray-700 px-4 py-3">
              <span className="text-sm text-gray-400">Total</span>
              <span className="text-2xl font-bold text-white">{formatoBs(total)}</span>
            </div>

            <button
              type="submit"
              disabled={guardando}
              className="w-full flex justify-center rounded-lg bg-blue-600 px-4 py-3 text-sm font-semibold text-white hover:bg-blue-500 disabled:opacity-50 transition-colors cursor-pointer"
            >
              {guardando ? 'Registrando...' : 'Registrar venta'}
            </button>
          </form>
        </div>

        {/* ============================================================
             CUADERNO DE REGISTROS
        ============================================================ */}
        <div className="rounded-2xl bg-gray-900 border border-gray-800 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Undo2 className="h-5 w-5 text-amber-400" />
              <h2 className="text-lg font-semibold text-white">Cuaderno de registros</h2>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <input
                type="date"
                value={desde}
                onChange={(e) => setDesde(e.target.value)}
                className="rounded-lg bg-gray-800 border border-gray-700 px-2 py-1.5 text-sm text-white focus:border-blue-500 focus:outline-none"
              />
              <span className="text-gray-500">a</span>
              <input
                type="date"
                value={hasta}
                onChange={(e) => setHasta(e.target.value)}
                className="rounded-lg bg-gray-800 border border-gray-700 px-2 py-1.5 text-sm text-white focus:border-blue-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="rounded-lg border border-gray-700 overflow-x-auto max-h-[640px] overflow-y-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-800 text-left text-xs uppercase tracking-wider text-gray-400 sticky top-0">
                <tr>
                  <th className="px-3 py-2">Código</th>
                  <th className="px-3 py-2">Fecha/Hora</th>
                  <th className="px-3 py-2">Cliente</th>
                  <th className="px-3 py-2">Vendedor</th>
                  <th className="px-3 py-2">Artículos</th>
                  <th className="px-3 py-2 text-right">Total</th>
                  <th className="px-3 py-2">Estado</th>
                  <th className="px-3 py-2"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-700">
                {ventas.map((v) => (
                  <tr key={v.id} className={v.estado === 'ANULADA' ? 'opacity-50' : ''}>
                    <td className="px-3 py-2 font-mono text-xs">{v.codigo}</td>
                    <td className="px-3 py-2 text-gray-400">{new Date(v.fecha).toLocaleString('es-BO')}</td>
                    <td className="px-3 py-2">{v.cliente?.nombre || 'Mostrador'}</td>
                    <td className="px-3 py-2">{v.usuario?.nombre || '—'}</td>
                    <td className="px-3 py-2 text-center">{v.detalle.reduce((a, d) => a + d.cantidad, 0)}</td>
                    <td className="px-3 py-2 text-right font-semibold">
                      {Number(v.descuento) > 0 && (
                        <span className="block text-xs text-gray-500 line-through">
                          {formatoBs(v.subtotal)}
                        </span>
                      )}
                      {formatoBs(v.total)}
                    </td>
                    <td className="px-3 py-2">
                      <span
                        className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                          v.estado === 'COMPLETADA'
                            ? 'bg-emerald-500/10 text-emerald-400'
                            : 'bg-red-500/10 text-red-400'
                        }`}
                      >
                        {v.estado === 'COMPLETADA' ? 'Completada' : 'Anulada'}
                      </span>
                    </td>
                    <td className="px-3 py-2 text-right">
                      {v.estado === 'COMPLETADA' && (
                        <button
                          onClick={() => anular(v)}
                          className="rounded p-1 text-gray-500 hover:text-red-400 transition-colors cursor-pointer"
                          title="Anular venta (reponer stock)"
                        >
                          <Undo2 className="h-4 w-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
                {ventas.length === 0 && (
                  <tr>
                    <td colSpan={8} className="px-3 py-8 text-center text-gray-500">
                      No hay registros en el rango seleccionado.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};