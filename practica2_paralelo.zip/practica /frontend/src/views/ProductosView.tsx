// src/views/ProductosView.tsx
import React, { useCallback, useEffect, useState } from 'react';
import { Plus, Pencil, Power, PackageSearch } from 'lucide-react';
import { listarProductos, crearProducto, actualizarProducto, ProductoPayload } from '../services/productos.service';
import { listarCategorias } from '../services/catalogos.service';
import { extraerMensajeError } from '../services/httpClient';
import { Modal } from '../components/common/Modal';
import { Categoria, Producto } from '../interfaces/entidades';

const formatoBs = (n: number | string) =>
  `Bs ${Number(n).toLocaleString('es-BO', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

const formularioVacio: ProductoPayload = {
  codigo: '',
  nombre: '',
  marca: '',
  descripcion: '',
  categoriaId: undefined,
  precioCompra: 0,
  precioVenta: 0,
  stock: 0,
  stockMinimo: 0,
};

export const ProductosView: React.FC = () => {
  const [productos, setProductos] = useState<Producto[]>([]);
  const [categorias, setCategorias] = useState<Categoria[]>([]);
  const [search, setSearch] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editando, setEditando] = useState<Producto | null>(null);
  const [form, setForm] = useState<ProductoPayload>(formularioVacio);
  const [guardando, setGuardando] = useState(false);
  const [mensaje, setMensaje] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const cargar = useCallback(async () => {
    setError(null);
    try {
      const [prods, cats] = await Promise.all([
        listarProductos({ incluirInactivos: true }),
        listarCategorias(),
      ]);
      setProductos(prods);
      setCategorias(cats);
    } catch (err: any) {
      setError(extraerMensajeError(err));
    }
  }, []);

  useEffect(() => {
    cargar();
  }, [cargar]);

  const abrirCrear = () => {
    setEditando(null);
    setForm(formularioVacio);
    setModalOpen(true);
  };

  const abrirEditar = (p: Producto) => {
    setEditando(p);
    setForm({
      codigo: p.codigo,
      nombre: p.nombre,
      marca: p.marca || '',
      descripcion: p.descripcion || '',
      categoriaId: p.categoriaId,
      precioCompra: Number(p.precioCompra),
      precioVenta: Number(p.precioVenta),
      stock: p.stock,
      stockMinimo: p.stockMinimo,
    });
    setModalOpen(true);
  };

  const setCampo = (campo: keyof ProductoPayload, valor: any) =>
    setForm((f) => ({ ...f, [campo]: valor }));

  const guardar = async (e: React.FormEvent) => {
    e.preventDefault();
    setGuardando(true);
    setMensaje(null);
    try {
      if (editando) {
        await actualizarProducto(editando.id, form);
        setMensaje(`Producto "${form.nombre}" actualizado correctamente.`);
      } else {
        await crearProducto(form);
        setMensaje(`Producto "${form.nombre}" creado correctamente.`);
      }
      setModalOpen(false);
      await cargar();
    } catch (err: any) {
      setError(extraerMensajeError(err));
    } finally {
      setGuardando(false);
    }
  };

  const alternarActivo = async (p: Producto) => {
    setError(null);
    try {
      await actualizarProducto(p.id, { activo: !p.activo });
      await cargar();
    } catch (err: any) {
      setError(extraerMensajeError(err));
    }
  };

  const filtrados = productos.filter((p) => {
    const term = search.toLowerCase().trim();
    if (!term) return true;
    return (
      p.nombre.toLowerCase().includes(term) ||
      p.codigo.toLowerCase().includes(term) ||
      (p.marca || '').toLowerCase().includes(term)
    );
  });

  const activos = filtrados.filter((p) => p.activo).length;

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white">Productos</h1>
          <p className="text-sm text-gray-400">
            {activos} activos de {filtrados.length} mostrados
          </p>
        </div>
        <button
          onClick={abrirCrear}
          className="flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-500 transition-colors cursor-pointer"
        >
          <Plus className="h-4 w-4" />
          Agregar producto
        </button>
      </div>

      {mensaje && (
        <div className="mb-4 rounded-lg bg-emerald-500/10 border border-emerald-500/20 p-3 text-sm text-emerald-400">
          {mensaje}
        </div>
      )}
      {error && (
        <div className="mb-4 rounded-lg bg-red-500/10 border border-red-500/20 p-3 text-sm text-red-400">
          {error}
        </div>
      )}

      <div className="mb-4 max-w-sm">
        <div className="relative">
          <PackageSearch className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar por nombre, código o marca..."
            className="w-full rounded-lg bg-gray-900 border border-gray-700 pl-9 pr-4 py-2.5 text-sm text-white placeholder-gray-500 focus:border-blue-500 focus:outline-none"
          />
        </div>
      </div>

      <div className="rounded-xl bg-gray-900 border border-gray-800 overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-gray-800/60 text-left text-xs uppercase tracking-wider text-gray-400">
            <tr>
              <th className="px-4 py-3">Código</th>
              <th className="px-4 py-3">Nombre</th>
              <th className="px-4 py-3">Categoría</th>
              <th className="px-4 py-3 text-right">P. Compra</th>
              <th className="px-4 py-3 text-right">P. Venta</th>
              <th className="px-4 py-3 text-center">Stock</th>
              <th className="px-4 py-3">Estado</th>
              <th className="px-4 py-3 text-right">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-800">
            {filtrados.map((p) => {
              const stockBajo = p.activo && p.stock <= p.stockMinimo;
              return (
                <tr key={p.id} className={p.activo ? '' : 'opacity-50'}>
                  <td className="px-4 py-3 font-mono text-xs">{p.codigo}</td>
                  <td className="px-4 py-3 font-medium">
                    {p.nombre}
                    {p.marca && <span className="block text-xs text-gray-500">{p.marca}</span>}
                  </td>
                  <td className="px-4 py-3 text-gray-400">{p.categoria?.nombre || '—'}</td>
                  <td className="px-4 py-3 text-right text-gray-400">{formatoBs(p.precioCompra)}</td>
                  <td className="px-4 py-3 text-right font-semibold">{formatoBs(p.precioVenta)}</td>
                  <td className="px-4 py-3 text-center">
                    <span
                      className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                        stockBajo
                          ? 'bg-amber-500/10 text-amber-400'
                          : 'bg-gray-700/40 text-gray-300'
                      }`}
                      title={stockBajo ? 'Stock por debajo del mínimo' : ''}
                    >
                      {p.stock}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                        p.activo ? 'bg-emerald-500/10 text-emerald-400' : 'bg-gray-700/40 text-gray-400'
                      }`}
                    >
                      {p.activo ? 'Activo' : 'Inactivo'}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => abrirEditar(p)}
                        className="rounded-lg p-2 text-gray-400 hover:bg-gray-800 hover:text-blue-400 transition-colors cursor-pointer"
                        title="Editar precios y stock"
                      >
                        <Pencil className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => alternarActivo(p)}
                        className={`rounded-lg p-2 transition-colors cursor-pointer ${
                          p.activo
                            ? 'text-gray-400 hover:bg-gray-800 hover:text-red-400'
                            : 'text-emerald-400 hover:bg-gray-800'
                        }`}
                        title={p.activo ? 'Desactivar producto' : 'Reactivar producto'}
                      >
                        <Power className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
            {filtrados.length === 0 && (
              <tr>
                <td colSpan={8} className="px-4 py-8 text-center text-gray-500">
                  No se encontraron productos.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <Modal
        title={editando ? `Editar: ${editando.nombre}` : 'Agregar producto'}
        open={modalOpen}
        onClose={() => setModalOpen(false)}
      >
        <form onSubmit={guardar} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="flex flex-col col-span-1">
              <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">Código *</label>
              <input
                required
                value={form.codigo}
                onChange={(e) => setCampo('codigo', e.target.value)}
                className="rounded-lg bg-gray-800 border border-gray-700 px-3 py-2 text-sm text-white focus:border-blue-500 focus:outline-none"
                placeholder="PRO-0023"
              />
            </div>
            <div className="flex flex-col">
              <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">Categoría *</label>
              <select
                required
                value={form.categoriaId || ''}
                onChange={(e) => setCampo('categoriaId', Number(e.target.value))}
                className="rounded-lg bg-gray-800 border border-gray-700 px-3 py-2 text-sm text-white focus:border-blue-500 focus:outline-none"
              >
                <option value="" disabled>Seleccione...</option>
                {categorias.map((c) => (
                  <option key={c.id} value={c.id}>{c.nombre}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex flex-col">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">Nombre *</label>
            <input
              required
              value={form.nombre}
              onChange={(e) => setCampo('nombre', e.target.value)}
              className="rounded-lg bg-gray-800 border border-gray-700 px-3 py-2 text-sm text-white focus:border-blue-500 focus:outline-none"
              placeholder="Nombre del producto"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="flex flex-col">
              <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">Marca</label>
              <input
                value={form.marca}
                onChange={(e) => setCampo('marca', e.target.value)}
                className="rounded-lg bg-gray-800 border border-gray-700 px-3 py-2 text-sm text-white focus:border-blue-500 focus:outline-none"
                placeholder="Opcional"
              />
            </div>
            <div className="flex flex-col">
              <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">Descripción</label>
              <input
                value={form.descripcion}
                onChange={(e) => setCampo('descripcion', e.target.value)}
                className="rounded-lg bg-gray-800 border border-gray-700 px-3 py-2 text-sm text-white focus:border-blue-500 focus:outline-none"
                placeholder="Opcional"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="flex flex-col">
              <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">Precio compra (Bs)</label>
              <input
                type="number"
                min={0}
                step="0.01"
                value={form.precioCompra}
                onChange={(e) => setCampo('precioCompra', Number(e.target.value))}
                className="rounded-lg bg-gray-800 border border-gray-700 px-3 py-2 text-sm text-white focus:border-blue-500 focus:outline-none"
              />
            </div>
            <div className="flex flex-col">
              <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">Precio venta (Bs)</label>
              <input
                type="number"
                min={0}
                step="0.01"
                value={form.precioVenta}
                onChange={(e) => setCampo('precioVenta', Number(e.target.value))}
                className="rounded-lg bg-gray-800 border border-gray-700 px-3 py-2 text-sm text-white focus:border-blue-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="flex flex-col">
              <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">Stock inicial</label>
              <input
                type="number"
                min={0}
                value={form.stock}
                onChange={(e) => setCampo('stock', Number(e.target.value))}
                className="rounded-lg bg-gray-800 border border-gray-700 px-3 py-2 text-sm text-white focus:border-blue-500 focus:outline-none"
              />
            </div>
            <div className="flex flex-col">
              <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">Stock mínimo</label>
              <input
                type="number"
                min={0}
                value={form.stockMinimo}
                onChange={(e) => setCampo('stockMinimo', Number(e.target.value))}
                className="rounded-lg bg-gray-800 border border-gray-700 px-3 py-2 text-sm text-white focus:border-blue-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="rounded-lg px-4 py-2 text-sm font-medium text-gray-400 hover:bg-gray-800 transition-colors cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={guardando}
              className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-500 disabled:opacity-50 transition-colors cursor-pointer"
            >
              {guardando ? 'Guardando...' : editando ? 'Guardar cambios' : 'Crear producto'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};