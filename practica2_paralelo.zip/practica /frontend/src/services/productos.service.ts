// src/services/productos.service.ts
import { httpClient } from './httpClient';
import { Producto } from '../interfaces/entidades';

export interface ProductoPayload {
  codigo?: string;
  nombre?: string;
  marca?: string;
  descripcion?: string;
  categoriaId?: number;
  precioCompra?: number;
  precioVenta?: number;
  stock?: number;
  stockMinimo?: number;
  activo?: boolean;
}

export async function listarProductos(opts: { search?: string; incluirInactivos?: boolean } = {}): Promise<Producto[]> {
  const { data } = await httpClient.get<{ status: string; data: Producto[] }>('/productos', {
    params: {
      search: opts.search || undefined,
      incluirInactivos: opts.incluirInactivos ? '1' : undefined,
    },
  });
  return data.data;
}

export async function crearProducto(payload: ProductoPayload): Promise<Producto> {
  const { data } = await httpClient.post<{ status: string; data: Producto }>('/productos', payload);
  return data.data;
}

export async function actualizarProducto(id: number, payload: ProductoPayload): Promise<Producto> {
  const { data } = await httpClient.put<{ status: string; data: Producto }>(`/productos/${id}`, payload);
  return data.data;
}