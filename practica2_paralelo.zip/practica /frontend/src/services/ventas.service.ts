// src/services/ventas.service.ts
import { httpClient } from './httpClient';
import { ItemVenta, Venta, ResumenDashboard } from '../interfaces/entidades';

export interface RegistrarVentaPayload {
  clienteId?: number;
  descuento?: number;
  items: ItemVenta[];
}

export async function registrarVenta(payload: RegistrarVentaPayload): Promise<Venta> {
  const { data } = await httpClient.post<{ status: string; data: Venta }>('/ventas', payload);
  return data.data;
}

export async function listarVentas(opts: { desde?: string; hasta?: string } = {}): Promise<Venta[]> {
  const { data } = await httpClient.get<{ status: string; data: Venta[] }>('/ventas', { params: opts });
  return data.data;
}

export async function anularVenta(id: number): Promise<Venta> {
  const { data } = await httpClient.post<{ status: string; data: Venta }>(`/ventas/${id}/anular`);
  return data.data;
}

export async function obtenerResumen(): Promise<ResumenDashboard> {
  const { data } = await httpClient.get<{ status: string; data: ResumenDashboard }>('/dashboard/resumen');
  return data.data;
}