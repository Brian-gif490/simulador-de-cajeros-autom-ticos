// src/services/catalogos.service.ts
import { httpClient } from './httpClient';
import { Categoria, Cliente } from '../interfaces/entidades';

export async function listarCategorias(): Promise<Categoria[]> {
  const { data } = await httpClient.get<{ status: string; data: Categoria[] }>('/categorias');
  return data.data;
}

export async function listarClientes(): Promise<Cliente[]> {
  const { data } = await httpClient.get<{ status: string; data: Cliente[] }>('/clientes');
  return data.data;
}

export async function crearCliente(payload: { nombre: string; nit?: string }): Promise<Cliente> {
  const { data } = await httpClient.post<{ status: string; data: Cliente }>('/clientes', payload);
  return data.data;
}