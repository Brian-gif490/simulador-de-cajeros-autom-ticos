// src/services/auth.service.ts
import { httpClient } from './httpClient';
import { Usuario } from '../interfaces/auth.interface';

export interface LoginResponse {
  status: string;
  token: string;
  data: { usuario: Usuario };
}

export async function loginRequest(correo: string, password: string): Promise<LoginResponse> {
  const { data } = await httpClient.post<LoginResponse>('/auth/login', { correo, password });
  return data;
}

export async function meRequest(): Promise<Usuario> {
  const { data } = await httpClient.get<{ status: string; data: { usuario: Usuario } }>('/auth/me');
  return data.data.usuario;
}