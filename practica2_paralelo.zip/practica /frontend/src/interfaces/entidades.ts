// src/interfaces/entidades.ts
export interface Categoria {
  id: number;
  nombre: string;
  descripcion?: string | null;
  activo: boolean;
}

export interface Producto {
  id: number;
  codigo: string;
  nombre: string;
  descripcion?: string | null;
  marca?: string | null;
  precioCompra: string;
  precioVenta: string;
  stock: number;
  stockMinimo: number;
  activo: boolean;
  categoriaId: number;
  categoria?: { id: number; nombre: string } | null;
}

export interface Cliente {
  id: number;
  nombre: string;
  nit?: string | null;
  telefono?: string | null;
}

export interface DetalleVenta {
  id: number;
  cantidad: number;
  precioUnitario: string;
  subtotal: string;
  producto?: { id: number; codigo: string; nombre: string } | null;
}

export interface Venta {
  id: number;
  codigo: string;
  fecha: string;
  subtotal: string;
  descuento: string;
  total: string;
  estado: string;
  cliente?: Cliente | null;
  usuario?: { id: number; nombre: string } | null;
  detalle: DetalleVenta[];
}

export interface ItemVenta {
  productoId: number;
  cantidad: number;
}

export interface ResumenDashboard {
  productosActivos: number;
  stockBajo: number;
  ventas: number;
  ventasHoy: number;
  ingresosTotales: number;
  ingresosHoy: number;
  ultimasVentas: Venta[];
}