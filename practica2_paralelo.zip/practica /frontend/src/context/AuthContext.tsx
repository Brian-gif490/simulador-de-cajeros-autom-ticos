// src/context/AuthContext.tsx
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Usuario, AuthContextType } from '../interfaces/auth.interface';
import { loginRequest, meRequest } from '../services/auth.service';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<Usuario | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  const logout = () => {
    localStorage.removeItem('papeleria_token');
    setUser(null);
  };

  useEffect(() => {
    const verificarSesion = async () => {
      const token = localStorage.getItem('papeleria_token');
      if (!token) {
        setLoading(false);
        return;
      }
      try {
        const usuario = await meRequest();
        setUser(usuario);
      } catch {
        localStorage.removeItem('papeleria_token');
      } finally {
        setLoading(false);
      }
    };

    const manejarDesautenticacion = () => logout();
    window.addEventListener('auth_unauthorized', manejarDesautenticacion);

    verificarSesion();

    return () => window.removeEventListener('auth_unauthorized', manejarDesautenticacion);
  }, []);

  const login = async (correo: string, password: string) => {
    try {
      const data = await loginRequest(correo, password);
      if (!data.token || !data.data?.usuario) throw new Error('Estructura de respuesta inválida');
      localStorage.setItem('papeleria_token', data.token);
      setUser(data.data.usuario);
    } catch (error: any) {
      throw new Error(error?.response?.data?.message || error?.message || 'Error al autenticar');
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth debe usarse dentro de AuthProvider');
  return context;
};