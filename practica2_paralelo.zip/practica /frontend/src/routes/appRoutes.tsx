// src/routes/appRoutes.tsx
import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';

import { LoginView } from '../views/login/LoginView';
import { ProtectedRoute } from './ProtectedRoute';
import { DashboardLayout } from '../layouts/DashboardLayout';
import { DashboardView } from '../views/DashboardView';
import { ProductosView } from '../views/ProductosView';
import { CajaView } from '../views/CajaView';

export const AppRoutes: React.FC = () => {
  return (
    <Routes>
      {/* Ruta pública */}
      <Route path="/login" element={<LoginView />} />

      {/* Rutas protegidas con panel y sidebar */}
      <Route element={<ProtectedRoute />}>
        <Route element={<DashboardLayout />}>
          <Route path="/dashboard" element={<DashboardView />} />
          <Route path="/productos" element={<ProductosView />} />
          <Route path="/caja" element={<CajaView />} />
        </Route>
      </Route>

      {/* Redirecciones por defecto */}
      <Route path="/" element={<Navigate to="/dashboard" replace />} />
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
};