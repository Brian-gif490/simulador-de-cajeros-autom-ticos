// backend/prisma.config.ts
import { defineConfig } from '@prisma/config';

export default defineConfig({
  datasource: {
    url: process.env.DATABASE_URL || 'postgresql://admin_papeleria:SecretPassword2026@postgres-db:5432/papeleria_db?schema=public',
  },
  migrations: {
    seed: 'node ./prisma/seed.js',
  },
});