// src/services/clientes.service.ts
import { prisma } from '../config/prisma.js';
import { AppError } from '../utils/appError.js';

export interface ClienteInput {
  nombre: string;
  nit?: string;
  correo?: string;
  telefono?: string;
  direccion?: string;
}

export class ClientesService {
  async listar(search?: string) {
    return prisma.cliente.findMany({
      where: {
        activo: true,
        ...(search
          ? {
              OR: [
                { nombre: { contains: search, mode: 'insensitive' } },
                { nit: { contains: search, mode: 'insensitive' } },
              ],
            }
          : {}),
      },
      orderBy: { nombre: 'asc' },
    });
  }

  async crear(data: ClienteInput) {
    const nombre = data.nombre?.trim();
    if (!nombre) {
      throw new AppError('El nombre del cliente es obligatorio.', 400);
    }

    if (data.nit) {
      const existente = await prisma.cliente.findUnique({ where: { nit: data.nit.trim() } });
      if (existente) {
        throw new AppError(`Ya existe un cliente con el NIT ${data.nit.trim()}.`, 400);
      }
    }

    return prisma.cliente.create({
      data: {
        nombre,
        nit: data.nit?.trim() || null,
        correo: data.correo?.trim() || null,
        telefono: data.telefono?.trim() || null,
        direccion: data.direccion?.trim() || null,
      },
    });
  }
}

export const clientesService = new ClientesService();