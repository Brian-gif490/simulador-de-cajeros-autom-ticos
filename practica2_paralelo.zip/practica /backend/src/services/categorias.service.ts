// src/services/categorias.service.ts
import { prisma } from '../config/prisma.js';

export class CategoriasService {
  async listar() {
    return prisma.categoria.findMany({
      where: { activo: true },
      orderBy: { nombre: 'asc' },
    });
  }
}

export const categoriasService = new CategoriasService();