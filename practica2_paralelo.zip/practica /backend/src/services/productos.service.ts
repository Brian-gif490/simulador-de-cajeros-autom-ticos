// src/services/productos.service.ts
import { prisma } from '../config/prisma.js';
import { AppError } from '../utils/appError.js';

export interface ProductoInput {
  codigo: string;
  nombre: string;
  marca?: string;
  descripcion?: string;
  categoriaId?: number;
  precioCompra?: number;
  precioVenta?: number;
  stock?: number;
  stockMinimo?: number;
  activo?: boolean;
}

export class ProductosService {
  async listar({ search, incluirInactivos }: { search?: string; incluirInactivos?: boolean }) {
    return prisma.producto.findMany({
      where: {
        ...(incluirInactivos ? {} : { activo: true }),
        ...(search
          ? {
              OR: [
                { nombre: { contains: search, mode: 'insensitive' } },
                { codigo: { contains: search, mode: 'insensitive' } },
                { marca: { contains: search, mode: 'insensitive' } },
              ],
            }
          : {}),
      },
      include: { categoria: { select: { id: true, nombre: true } } },
      orderBy: { id: 'desc' },
    });
  }

  async obtener(id: number) {
    const producto = await prisma.producto.findUnique({
      where: { id },
      include: { categoria: true },
    });
    if (!producto) {
      throw new AppError('El producto solicitado no existe.', 404);
    }
    return producto;
  }

  async crear(data: ProductoInput) {
    const codigo = data.codigo?.trim();
    const nombre = data.nombre?.trim();

    if (!codigo || !nombre) {
      throw new AppError('El código y el nombre del producto son obligatorios.', 400);
    }

    const existente = await prisma.producto.findUnique({ where: { codigo } });
    if (existente) {
      throw new AppError(`Ya existe un producto con el código ${codigo}.`, 400);
    }

    if (!data.categoriaId) {
      throw new AppError('Debe seleccionar una categoría.', 400);
    }

    return prisma.producto.create({
      data: {
        codigo,
        nombre,
        marca: data.marca?.trim() || null,
        descripcion: data.descripcion?.trim() || null,
        categoriaId: Number(data.categoriaId),
        precioCompra: Number(data.precioCompra) || 0,
        precioVenta: Number(data.precioVenta) || 0,
        stock: Number(data.stock) || 0,
        stockMinimo: Number(data.stockMinimo) || 0,
        activo: data.activo ?? true,
      },
      include: { categoria: { select: { id: true, nombre: true } } },
    });
  }

  async actualizar(id: number, data: ProductoInput) {
    await this.obtener(id); // lanza 404 si no existe

    if (data.codigo) {
      const existente = await prisma.producto.findUnique({ where: { codigo: data.codigo.trim() } });
      if (existente && existente.id !== id) {
        throw new AppError(`Ya existe un producto con el código ${data.codigo.trim()}.`, 400);
      }
    }

    const campos = {
      ...(data.nombre !== undefined ? { nombre: data.nombre.trim() } : {}),
      ...(data.marca !== undefined ? { marca: data.marca.trim() || null } : {}),
      ...(data.descripcion !== undefined ? { descripcion: data.descripcion.trim() || null } : {}),
      ...(data.categoriaId !== undefined ? { categoriaId: Number(data.categoriaId) } : {}),
      ...(data.precioCompra !== undefined ? { precioCompra: Number(data.precioCompra) || 0 } : {}),
      ...(data.precioVenta !== undefined ? { precioVenta: Number(data.precioVenta) || 0 } : {}),
      ...(data.stock !== undefined ? { stock: Number(data.stock) || 0 } : {}),
      ...(data.stockMinimo !== undefined ? { stockMinimo: Number(data.stockMinimo) || 0 } : {}),
      ...(data.activo !== undefined ? { activo: data.activo } : {}),
    };

    return prisma.producto.update({
      where: { id },
      data: campos,
      include: { categoria: { select: { id: true, nombre: true } } },
    });
  }
}

export const productosService = new ProductosService();