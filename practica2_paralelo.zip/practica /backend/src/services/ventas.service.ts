// src/services/ventas.service.ts
import { prisma } from '../config/prisma.js';
import { AppError } from '../utils/appError.js';

export interface ItemVenta {
  productoId: number;
  cantidad: number;
}

export class VentasService {
  async registrar(data: {
    clienteId?: number;
    descuento?: number;
    usuarioId: number;
    items: ItemVenta[];
  }) {
    if (!Array.isArray(data.items) || data.items.length === 0) {
      throw new AppError('Debe registrar al menos un producto en la venta.', 400);
    }

    const ids = data.items.map((i) => Number(i.productoId));
    const productos = await prisma.producto.findMany({ where: { id: { in: ids } } });

    let subtotal = 0;
    const detalleData = data.items.map((item) => {
      const producto = productos.find((p) => p.id === Number(item.productoId));
      if (!producto) {
        throw new AppError(`Uno de los productos seleccionados no existe.`, 400);
      }
      const cantidad = Number(item.cantidad);
      if (!Number.isInteger(cantidad) || cantidad <= 0) {
        throw new AppError(`La cantidad de "${producto.nombre}" no es válida.`, 400);
      }
      if (producto.stock < cantidad) {
        throw new AppError(
          `Stock insuficiente para "${producto.nombre}". Disponible: ${producto.stock}.`,
          400
        );
      }
      const precio = Number(producto.precioVenta);
      const subtotalLinea = precio * cantidad;
      subtotal += subtotalLinea;
      return {
        productoId: producto.id,
        cantidad,
        precioUnitario: precio,
        subtotal: subtotalLinea,
      };
    });

    const descuento = Math.max(0, Number(data.descuento) || 0);
    const total = Math.max(0, subtotal - descuento);

    // Código secuencial de la venta (V-0000001, V-0000002, ...)
    const cantidadVentas = await prisma.venta.count();
    const codigo = `V-${String(cantidadVentas + 1).padStart(7, '0')}`;

    const venta = await prisma.$transaction(async (tx) => {
      // Descontar stock de forma atómica (solo si hay disponibilidad)
      for (const d of detalleData) {
        const resultado = await tx.producto.updateMany({
          where: { id: d.productoId, stock: { gte: d.cantidad } },
          data: { stock: { decrement: d.cantidad } },
        });
        if (resultado.count === 0) {
          throw new AppError('No hay stock suficiente para completar la venta.', 400);
        }
      }

      return tx.venta.create({
        data: {
          codigo,
          clienteId: data.clienteId ? Number(data.clienteId) : null,
          usuarioId: Number(data.usuarioId),
          subtotal,
          descuento,
          total,
          estado: 'COMPLETADA',
          detalle: { create: detalleData },
        },
        include: {
          cliente: true,
          usuario: { select: { id: true, nombre: true } },
          detalle: {
            include: { producto: { select: { id: true, codigo: true, nombre: true } } },
          },
        },
      });
    });

    return venta;
  }

  async listar({ desde, hasta, soloCompletadas }: { desde?: string; hasta?: string; soloCompletadas?: boolean }) {
    const fechaDesde = desde ? new Date(desde as string) : null;
    const fechaHasta = hasta ? new Date(hasta as string) : null;
    if (fechaHasta && !Number.isNaN(fechaHasta.getTime())) {
      fechaHasta.setHours(23, 59, 59, 999);
    }

    return prisma.venta.findMany({
      where: {
        ...(fechaDesde && !Number.isNaN(fechaDesde.getTime())
          ? { fecha: { gte: fechaDesde } }
          : {}),
        ...(fechaHasta && !Number.isNaN(fechaHasta.getTime())
          ? { fecha: { lte: fechaHasta } }
          : {}),
        ...(soloCompletadas ? { estado: 'COMPLETADA' } : {}),
      },
      include: {
        cliente: true,
        usuario: { select: { id: true, nombre: true } },
        detalle: {
          include: { producto: { select: { id: true, codigo: true, nombre: true } } },
        },
      },
      orderBy: { fecha: 'desc' },
    });
  }

  async obtener(id: number) {
    const venta = await prisma.venta.findUnique({
      where: { id },
      include: {
        cliente: true,
        usuario: { select: { id: true, nombre: true } },
        detalle: {
          include: { producto: { select: { id: true, codigo: true, nombre: true } } },
        },
      },
    });
    if (!venta) {
      throw new AppError('La venta solicitada no existe.', 404);
    }
    return venta;
  }

  async anular(id: number) {
    const venta = await prisma.venta.findUnique({ where: { id }, include: { detalle: true } });
    if (!venta) {
      throw new AppError('La venta solicitada no existe.', 404);
    }
    if (venta.estado === 'ANULADA') {
      throw new AppError('La venta ya fue anulada previamente.', 400);
    }

    await prisma.$transaction(async (tx) => {
      // Devolver el stock al inventario
      for (const d of venta.detalle) {
        await tx.producto.update({
          where: { id: d.productoId },
          data: { stock: { increment: d.cantidad } },
        });
      }
      await tx.venta.update({ where: { id }, data: { estado: 'ANULADA' } });
    });

    return this.obtener(id);
  }
}

export const ventasService = new VentasService();