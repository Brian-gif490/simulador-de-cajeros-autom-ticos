// src/services/auth.service.ts
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { prisma } from '../config/prisma.js';
import { AppError } from '../utils/appError.js';

export class AuthService {
  private firmarToken(payload: { id: number; nombre: string; correo: string; rol: string }): string {
    return jwt.sign(
      payload,
      process.env.JWT_SECRET || 'papeleria_secreto_super_seguro_2026',
      { expiresIn: (process.env.JWT_EXPIRES_IN || '8h') as any }
    );
  }

  async login(correo: string, passwordPlain: string) {
    const user = await prisma.usuario.findUnique({
      where: { correo },
      include: { rol: true },
    });

    if (!user) {
      throw new AppError('Credenciales incorrectas.', 401);
    }

    if (!user.activo) {
      throw new AppError('Esta cuenta se encuentra suspendida. Contacte al Administrador.', 403);
    }

    const isPasswordValid = await bcrypt.compare(passwordPlain, user.password);
    if (!isPasswordValid) {
      throw new AppError('Credenciales incorrectas.', 401);
    }

    const rol = user.rol?.nombre || '';
    const token = this.firmarToken({
      id: user.id,
      nombre: user.nombre,
      correo: user.correo,
      rol,
    });

    return {
      token,
      usuario: {
        id: user.id,
        nombre: user.nombre,
        correo: user.correo,
        rol,
      },
    };
  }

  async obtenerUsuarioAutenticado(usuarioId: number) {
    const user = await prisma.usuario.findUnique({
      where: { id: usuarioId },
      include: { rol: true },
    });

    if (!user || !user.activo) {
      throw new AppError('La sesión no es válida o la cuenta fue desactivada.', 401);
    }

    return {
      id: user.id,
      nombre: user.nombre,
      correo: user.correo,
      rol: user.rol?.nombre || '',
    };
  }
}

export const authService = new AuthService();