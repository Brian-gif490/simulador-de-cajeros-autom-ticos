// src/interfaces/auth.interface.ts
export interface IJwtPayload {
  id: number;
  nombre: string;
  correo: string;
  rol: string;
}