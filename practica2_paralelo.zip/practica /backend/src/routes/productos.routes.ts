// src/routes/productos.routes.ts
import { Router } from 'express';
import { productosController } from '../controllers/productos.controller.js';
import { verificarJWT } from '../middlewares/auth.middleware.js';

const router = Router();

router.use(verificarJWT);

router.get('/', productosController.listar);
router.post('/', productosController.crear);
router.get('/:id', productosController.obtener);
router.put('/:id', productosController.actualizar);

export default router;