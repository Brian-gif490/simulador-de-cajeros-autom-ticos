// src/routes/ventas.routes.ts
import { Router } from 'express';
import { ventasController } from '../controllers/ventas.controller.js';
import { verificarJWT } from '../middlewares/auth.middleware.js';

const router = Router();

router.use(verificarJWT);

router.get('/', ventasController.listar);
router.post('/', ventasController.registrar);
router.get('/:id', ventasController.obtener);
router.post('/:id/anular', ventasController.anular);

export default router;