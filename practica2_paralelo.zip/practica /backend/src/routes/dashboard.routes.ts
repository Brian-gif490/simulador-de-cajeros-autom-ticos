// src/routes/dashboard.routes.ts
import { Router } from 'express';
import { dashboardController } from '../controllers/dashboard.controller.js';
import { verificarJWT } from '../middlewares/auth.middleware.js';

const router = Router();

router.use(verificarJWT);

router.get('/resumen', dashboardController.resumen);

export default router;