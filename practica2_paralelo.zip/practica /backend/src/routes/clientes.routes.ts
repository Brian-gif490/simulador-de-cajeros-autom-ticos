// src/routes/clientes.routes.ts
import { Router } from 'express';
import { clientesController } from '../controllers/clientes.controller.js';
import { verificarJWT } from '../middlewares/auth.middleware.js';

const router = Router();

router.use(verificarJWT);

router.get('/', clientesController.listar);
router.post('/', clientesController.crear);

export default router;