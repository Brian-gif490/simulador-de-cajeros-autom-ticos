// src/routes/auth.routes.ts
import { Router } from 'express';
import { authController } from '../controllers/auth.controller.js';
import { verificarJWT } from '../middlewares/auth.middleware.js';

const router = Router();

// POST /api/auth/login -> Endpoint público de acceso
router.post('/login', authController.login);

// GET /api/auth/me -> Datos del usuario autenticado
router.get('/me', verificarJWT, authController.me);

export default router;