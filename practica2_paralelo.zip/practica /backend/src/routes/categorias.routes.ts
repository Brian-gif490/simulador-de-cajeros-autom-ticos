// src/routes/categorias.routes.ts
import { Router } from 'express';
import { categoriasController } from '../controllers/categorias.controller.js';
import { verificarJWT } from '../middlewares/auth.middleware.js';

const router = Router();

router.use(verificarJWT);

router.get('/', categoriasController.listar);

export default router;