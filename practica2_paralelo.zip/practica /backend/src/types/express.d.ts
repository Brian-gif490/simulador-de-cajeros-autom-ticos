// src/types/express.d.ts
import { IJwtPayload } from '../interfaces/auth.interface.js';

declare global {
  namespace Express {
    interface Request {
      user?: {
        id: number;
        nombre: string;
        correo: string;
        rol: string;
      };
    }
  }
}

export {};