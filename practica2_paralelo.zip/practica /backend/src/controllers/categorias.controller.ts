// src/controllers/categorias.controller.ts
import { Request, Response, NextFunction } from 'express';
import { categoriasService } from '../services/categorias.service.js';

export class CategoriasController {
  async listar(_req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const categorias = await categoriasService.listar();
      res.status(200).json({ status: 'success', data: categorias });
    } catch (error) {
      next(error);
    }
  }
}

export const categoriasController = new CategoriasController();