// src/controllers/dashboard.controller.ts
import { Request, Response, NextFunction } from 'express';
import { prisma } from '../config/prisma.js';

export class DashboardController {
  async resumen(_req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const inicioDia = new Date();
      inicioDia.setHours(0, 0, 0, 0);

      const [productosActivos, stockBajo, ventas, ventasHoy, totalVentas, totalHoy] =
        await Promise.all([
          prisma.producto.count({ where: { activo: true } }),
          prisma.producto.count({ where: { activo: true, stock: { lte: prisma.producto.fields.stockMinimo } } }),
          prisma.venta.count(),
          prisma.venta.count({ where: { fecha: { gte: inicioDia } } }),
          prisma.venta.aggregate({
            where: { estado: 'COMPLETADA' },
            _sum: { total: true },
          }),
          prisma.venta.aggregate({
            where: { estado: 'COMPLETADA', fecha: { gte: inicioDia } },
            _sum: { total: true },
          }),
        ]);

      const ultimasVentas = await prisma.venta.findMany({
        take: 8,
        include: {
          cliente: true,
          usuario: { select: { id: true, nombre: true } },
          detalle: { select: { productoId: true, cantidad: true } },
        },
        orderBy: { fecha: 'desc' },
      });

      res.status(200).json({
        status: 'success',
        data: {
          productosActivos,
          stockBajo,
          ventas,
          ventasHoy,
          ingresosTotales: Number(totalVentas._sum?.total) || 0,
          ingresosHoy: Number(totalHoy._sum?.total) || 0,
          ultimasVentas,
        },
      });
    } catch (error) {
      next(error);
    }
  }
}

export const dashboardController = new DashboardController();