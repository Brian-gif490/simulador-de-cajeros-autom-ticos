// src/controllers/auth.controller.ts
import { Request, Response, NextFunction } from 'express';
import { authService } from '../services/auth.service.js';
import { AppError } from '../utils/appError.js';

export class AuthController {
  async login(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { correo, password } = req.body;

      if (!correo || !password) {
        throw new AppError('Por favor, proporcione el correo y la contraseña.', 400);
      }

      const resultado = await authService.login(correo, password);

      res.status(200).json({
        status: 'success',
        token: resultado.token,
        data: { usuario: resultado.usuario },
      });
    } catch (error) {
      next(error);
    }
  }

  async me(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const usuario = await authService.obtenerUsuarioAutenticado((req as any).user.id);
      res.status(200).json({
        status: 'success',
        data: { usuario },
      });
    } catch (error) {
      next(error);
    }
  }
}

export const authController = new AuthController();