// src/controllers/productos.controller.ts
import { Request, Response, NextFunction } from 'express';
import { productosService } from '../services/productos.service.js';

export class ProductosController {
  async listar(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { search, incluirInactivos } = req.query;
      const productos = await productosService.listar({
        search: search ? String(search) : undefined,
        incluirInactivos: incluirInactivos === '1' || incluirInactivos === 'true',
      });
      res.status(200).json({ status: 'success', data: productos });
    } catch (error) {
      next(error);
    }
  }

  async obtener(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const producto = await productosService.obtener(Number(req.params.id));
      res.status(200).json({ status: 'success', data: producto });
    } catch (error) {
      next(error);
    }
  }

  async crear(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const producto = await productosService.crear(req.body);
      res.status(201).json({ status: 'success', data: producto });
    } catch (error) {
      next(error);
    }
  }

  async actualizar(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const producto = await productosService.actualizar(Number(req.params.id), req.body);
      res.status(200).json({ status: 'success', data: producto });
    } catch (error) {
      next(error);
    }
  }
}

export const productosController = new ProductosController();