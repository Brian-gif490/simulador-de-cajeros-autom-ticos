// src/controllers/clientes.controller.ts
import { Request, Response, NextFunction } from 'express';
import { clientesService } from '../services/clientes.service.js';

export class ClientesController {
  async listar(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const clientes = await clientesService.listar(req.query.search ? String(req.query.search) : undefined);
      res.status(200).json({ status: 'success', data: clientes });
    } catch (error) {
      next(error);
    }
  }

  async crear(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const cliente = await clientesService.crear(req.body);
      res.status(201).json({ status: 'success', data: cliente });
    } catch (error) {
      next(error);
    }
  }
}

export const clientesController = new ClientesController();