// src/controllers/ventas.controller.ts
import { Request, Response, NextFunction } from 'express';
import { ventasService } from '../services/ventas.service.js';
import { AppError } from '../utils/appError.js';

export class VentasController {
  async registrar(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { clienteId, descuento, items } = req.body;
      const venta = await ventasService.registrar({
        clienteId,
        descuento,
        items,
        usuarioId: (req as any).user.id,
      });
      res.status(201).json({ status: 'success', data: venta });
    } catch (error) {
      next(error);
    }
  }

  async listar(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const ventas = await ventasService.listar({
        desde: req.query.desde ? String(req.query.desde) : undefined,
        hasta: req.query.hasta ? String(req.query.hasta) : undefined,
        soloCompletadas: req.query.completadas === '1' || req.query.completadas === 'true',
      });
      res.status(200).json({ status: 'success', data: ventas });
    } catch (error) {
      next(error);
    }
  }

  async obtener(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const venta = await ventasService.obtener(Number(req.params.id));
      res.status(200).json({ status: 'success', data: venta });
    } catch (error) {
      next(error);
    }
  }

  async anular(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const venta = await ventasService.anular(Number(req.params.id));
      res.status(200).json({ status: 'success', data: venta });
    } catch (error) {
      next(error);
    }
  }
}

export const ventasController = new VentasController();