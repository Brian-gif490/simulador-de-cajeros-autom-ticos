// backend/src/app.ts
import express, { Application, Request, Response, NextFunction } from 'express';
import cors from 'cors';
import authRouter from './routes/auth.routes.js';
import productosRoutes from './routes/productos.routes.js';
import categoriasRoutes from './routes/categorias.routes.js';
import clientesRoutes from './routes/clientes.routes.js';
import ventasRoutes from './routes/ventas.routes.js';
import dashboardRoutes from './routes/dashboard.routes.js';
import { errorHandler } from './middlewares/errorHandler.js';

const app: Application = express();

const rawOrigin = process.env.FRONTEND_URL || 'http://localhost:5175';
const cleanOrigin = rawOrigin.replace(/\/$/, '');
const allowedOrigins = [
  'http://localhost:5173',
  'http://localhost:5175',
  'http://127.0.0.1:5173',
  cleanOrigin,
  'http://0.0.0.0:5173',
];

app.use(
  cors({
    origin: allowedOrigins,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    credentials: true,
  })
);

app.use(express.json());

// Health Check
app.get('/api/health', (req: Request, res: Response) => {
  res.status(200).json({
    status: 'success',
    message: 'API de Gestión de Papelería respondiendo correctamente.',
    timestamp: new Date().toISOString(),
  });
});

app.get('/', (req: Request, res: Response) => {
  res.status(200).json({ project: 'Sistema de Gestión de Productos y Ventas - Papelería' });
});

// Montaje de rutas de la API
app.use('/api/auth', authRouter);
app.use('/api/productos', productosRoutes);
app.use('/api/categorias', categoriasRoutes);
app.use('/api/clientes', clientesRoutes);
app.use('/api/ventas', ventasRoutes);
app.use('/api/dashboard', dashboardRoutes);

// Manejo de rutas no encontradas
app.all('*', (req: Request, res: Response) => {
  res.status(404).json({ status: 'error', message: `Ruta no encontrada: ${req.originalUrl}` });
});

// Middleware global de errores
app.use(errorHandler);

export default app;