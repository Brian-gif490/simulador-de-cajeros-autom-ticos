// backend/prisma/seed.js
// Script de datos iniciales - Sistema de Gestión de Papelería (Productos y Ventas)
import pkg from 'pg';
const { Pool } = pkg;
import { PrismaPg } from '@prisma/adapter-pg';
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

// Inicialización del Driver Adapter requerido en el entorno Docker
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const adapter = new PrismaPg(pool);
const prisma = new PrismaClient({ adapter });

// Hash dinámico y real para la contraseña por defecto 'Papeleria2026*'
const DUMMY_PASSWORD_HASH = bcrypt.hashSync('Papeleria2026*', 10);

async function main() {
  console.log('🌱 Iniciando el proceso de Seeding (Datos maestros de la Papelería)...');

  // =========================================================================
  // 1. ROLES BASE
  // =========================================================================
  const rolAdmin = await prisma.rol.upsert({
    where: { nombre: 'Administrador' },
    update: {},
    create: { nombre: 'Administrador', descripcion: 'Acceso total al sistema de gestión' }
  });
  const rolVendedor = await prisma.rol.upsert({
    where: { nombre: 'Vendedor' },
    update: {},
    create: { nombre: 'Vendedor', descripcion: 'Registro de ventas y atención al cliente' }
  });

  console.log('✅ Roles base procesados con éxito.');

  // =========================================================================
  // 2. USUARIOS DEL SISTEMA
  // =========================================================================
  await prisma.usuario.upsert({
    where: { correo: 'admin.papeleria@empresa.com' },
    update: {},
    create: {
      nombre: 'Administrador General',
      correo: 'admin.papeleria@empresa.com',
      password: DUMMY_PASSWORD_HASH,
      rolId: rolAdmin.id
    }
  });
  await prisma.usuario.upsert({
    where: { correo: 'vendedor1.papeleria@empresa.com' },
    update: {},
    create: {
      nombre: 'Carlos Mamani',
      correo: 'vendedor1.papeleria@empresa.com',
      password: DUMMY_PASSWORD_HASH,
      rolId: rolVendedor.id
    }
  });
  await prisma.usuario.upsert({
    where: { correo: 'vendedor2.papeleria@empresa.com' },
    update: {},
    create: {
      nombre: 'María Rojas',
      correo: 'vendedor2.papeleria@empresa.com',
      password: DUMMY_PASSWORD_HASH,
      rolId: rolVendedor.id
    }
  });

  console.log('✅ Usuarios del sistema procesados correctamente.');

  // =========================================================================
  // 3. CATEGORÍAS DE PRODUCTOS
  // =========================================================================
  const categorias = [
    { nombre: 'Cuadernos y Libretas', descripcion: 'Cuadernos de todo tipo, libretas y agendas' },
    { nombre: 'Escritura', descripcion: 'Lapiceros, lápices, marcadores y bolígrafos' },
    { nombre: 'Papeleria y Resmas', descripcion: 'Resmas de papel, hojas y carpetas' },
    { nombre: 'Adhesivos y Corrección', descripcion: 'Cintas, pegamentos y correctores' },
    { nombre: 'Archivado', descripcion: 'Carátulas, separadores, fóldex y gomas' },
    { nombre: 'Arte y Dibujo', descripcion: 'Materiales de arte, pinturas y cartulinas' },
    { nombre: 'Oficina', descripcion: 'Útiles de escritorio y organización' }
  ];

  const categoriasCreadas = {};
  for (const c of categorias) {
    const cat = await prisma.categoria.upsert({
      where: { nombre: c.nombre },
      update: {},
      create: c
    });
    categoriasCreadas[c.nombre] = cat.id;
  }
  console.log(`✅ ${categorias.length} Categorías de productos procesadas.`);

  // =========================================================================
  // 4. PRODUCTOS (Catálogo de la Papelería)
  // =========================================================================
  const productos = [
    { codigo: 'PRO-0001', nombre: 'Cuaderno Universitario 100 hojas', marca: 'Norma', categoria: 'Cuadernos y Libretas', precioCompra: 6.5, precioVenta: 10.0, stock: 120, stockMinimo: 30 },
    { codigo: 'PRO-0002', nombre: 'Cuaderno Espiral 80 hojas', marca: 'Loro', categoria: 'Cuadernos y Libretas', precioCompra: 4.5, precioVenta: 8.0, stock: 85, stockMinimo: 20 },
    { codigo: 'PRO-0003', nombre: 'Libreta Rayada Mediana', marca: 'Carioca', categoria: 'Cuadernos y Libretas', precioCompra: 2.8, precioVenta: 5.5, stock: 60, stockMinimo: 15 },
    { codigo: 'PRO-0004', nombre: 'Bolígrafo Azul', marca: 'Bic', categoria: 'Escritura', precioCompra: 1.2, precioVenta: 2.5, stock: 300, stockMinimo: 50 },
    { codigo: 'PRO-0005', nombre: 'Bolígrafo Negro', marca: 'Bic', categoria: 'Escritura', precioCompra: 1.2, precioVenta: 2.5, stock: 250, stockMinimo: 50 },
    { codigo: 'PRO-0006', nombre: 'Lápiz Grafito N°2', marca: 'Faber Castell', categoria: 'Escritura', precioCompra: 0.8, precioVenta: 1.5, stock: 200, stockMinimo: 40 },
    { codigo: 'PRO-0007', nombre: 'Marcador Permanente Negro', marca: 'Sharpie', categoria: 'Escritura', precioCompra: 3.2, precioVenta: 6.0, stock: 90, stockMinimo: 20 },
    { codigo: 'PRO-0008', nombre: 'Resma Papel Bond A4 (500 hojas)', marca: 'Kilo', categoria: 'Papeleria y Resmas', precioCompra: 19.0, precioVenta: 26.0, stock: 70, stockMinimo: 15 },
    { codigo: 'PRO-0009', nombre: 'Papel Bond Carta (Quintilla)', marca: 'Kilo', categoria: 'Papeleria y Resmas', precioCompra: 10.0, precioVenta: 15.0, stock: 45, stockMinimo: 10 },
    { codigo: 'PRO-0010', nombre: 'Folders de Cartulina (x50)', marca: 'Papelera', categoria: 'Papeleria y Resmas', precioCompra: 9.0, precioVenta: 14.0, stock: 30, stockMinimo: 8 },
    { codigo: 'PRO-0011', nombre: 'Cinta Adhesiva 12mm', marca: 'Batty', categoria: 'Adhesivos y Corrección', precioCompra: 0.9, precioVenta: 2.0, stock: 150, stockMinimo: 30 },
    { codigo: 'PRO-0012', nombre: 'Pegamento Lápiz 40g', marca: 'Pritt', categoria: 'Adhesivos y Corrección', precioCompra: 3.5, precioVenta: 6.5, stock: 80, stockMinimo: 15 },
    { codigo: 'PRO-0013', nombre: 'Correctores Tapaltap (x10)', marca: 'Carioca', categoria: 'Adhesivos y Corrección', precioCompra: 2.0, precioVenta: 4.0, stock: 40, stockMinimo: 10 },
    { codigo: 'PRO-0014', nombre: 'Carátulas Plásticas (x50)', marca: 'Baco', categoria: 'Archivado', precioCompra: 8.0, precioVenta: 13.0, stock: 25, stockMinimo: 5 },
    { codigo: 'PRO-0015', nombre: 'Separadores Plásticos (x8)', marca: 'Norma', categoria: 'Archivado', precioCompra: 4.0, precioVenta: 7.0, stock: 55, stockMinimo: 12 },
    { codigo: 'PRO-0016', nombre: 'Goma de Borrar', marca: 'Milan', categoria: 'Archivado', precioCompra: 0.7, precioVenta: 1.5, stock: 180, stockMinimo: 30 },
    { codigo: 'PRO-0017', nombre: 'Caja de Colores (12 unidades)', marca: 'Faber Castell', categoria: 'Arte y Dibujo', precioCompra: 7.0, precioVenta: 12.0, stock: 35, stockMinimo: 8 },
    { codigo: 'PRO-0018', nombre: 'Cartulina Color A4 (x10)', marca: 'Canson', categoria: 'Arte y Dibujo', precioCompra: 3.0, precioVenta: 6.0, stock: 100, stockMinimo: 20 },
    { codigo: 'PRO-0019', nombre: 'Pinceles Set (5 unidades)', marca: 'Carioca', categoria: 'Arte y Dibujo', precioCompra: 5.5, precioVenta: 10.0, stock: 28, stockMinimo: 6 },
    { codigo: 'PRO-0020', nombre: 'Engrapadora N°10', marca: 'Artesco', categoria: 'Oficina', precioCompra: 9.5, precioVenta: 15.0, stock: 18, stockMinimo: 5 },
    { codigo: 'PRO-0021', nombre: 'Perforadora Metálica', marca: 'Artesco', categoria: 'Oficina', precioCompra: 12.0, precioVenta: 18.0, stock: 14, stockMinimo: 4 },
    { codigo: 'PRO-0022', nombre: 'Clips Metálicos (x100)', marca: 'Caroné', categoria: 'Oficina', precioCompra: 1.0, precioVenta: 2.2, stock: 120, stockMinimo: 25 }
  ];

  for (const p of productos) {
    await prisma.producto.upsert({
      where: { codigo: p.codigo },
      update: {},
      create: {
        codigo: p.codigo,
        nombre: p.nombre,
        marca: p.marca,
        categoriaId: categoriasCreadas[p.categoria],
        precioCompra: p.precioCompra,
        precioVenta: p.precioVenta,
        stock: p.stock,
        stockMinimo: p.stockMinimo
      }
    });
  }
  console.log(`✅ ${productos.length} Productos del catálogo procesados.`);

  // =========================================================================
  // 5. CLIENTES
  // =========================================================================
  const clientes = [
    { nombre: 'Cliente Ocasional (Sin NIT)', nit: null, telefono: 'N/A' },
    { nombre: 'Colegio San José', nit: '1020304012', telefono: '468-2001' },
    { nombre: 'Universidad Privada El Chaco', nit: '2010304023', telefono: '468-4507' },
    { nombre: 'Gobierno Municipal de Yacuiba', nit: '1020314055', telefono: '468-3005' }
  ];

  for (const cl of clientes) {
    if (!cl.nit) {
      const existente = await prisma.cliente.findFirst({ where: { nit: null } });
      if (!existente) {
        await prisma.cliente.create({ data: cl });
      }
    } else {
      await prisma.cliente.upsert({
        where: { nit: cl.nit },
        update: {},
        create: cl
      });
    }
  }
  console.log(`✅ ${clientes.length} Clientes procesados.`);

  // =========================================================================
  // 6. VENTAS DE EJEMPLO (Cabecera + Detalle)
  // =========================================================================
  const productoByCodigo = new Map();
  for (const p of productos) {
    const prod = await prisma.producto.findUnique({ where: { codigo: p.codigo } });
    productoByCodigo.set(p.codigo, prod);
  }
  const adminUsuario = await prisma.usuario.findUnique({ where: { correo: 'admin.papeleria@empresa.com' } });
  const vendedor1 = await prisma.usuario.findUnique({ where: { correo: 'vendedor1.papeleria@empresa.com' } });
  const clienteOcasional = await prisma.cliente.findFirst({ where: { nit: null } });
  const clienteColegio = await prisma.cliente.findFirst({ where: { nombre: 'Colegio San José' } });

  const ventasEjemplo = [
    {
      codigo: 'V-0000001',
      clienteId: clienteColegio.id,
      usuarioId: vendedor1.id,
      fecha: new Date('2026-09-15T10:30:00Z'),
      detalle: [
        { codigo: 'PRO-0001', cantidad: 50 },
        { codigo: 'PRO-0008', cantidad: 4 },
        { codigo: 'PRO-0004', cantidad: 20 }
      ]
    },
    {
      codigo: 'V-0000002',
      clienteId: clienteOcasional.id,
      usuarioId: vendedor1.id,
      fecha: new Date('2026-09-16T15:45:00Z'),
      detalle: [
        { codigo: 'PRO-0006', cantidad: 5 },
        { codigo: 'PRO-0012', cantidad: 2 },
        { codigo: 'PRO-0017', cantidad: 1 }
      ]
    },
    {
      codigo: 'V-0000003',
      clienteId: clienteColegio.id,
      usuarioId: adminUsuario.id,
      fecha: new Date('2026-09-18T09:15:00Z'),
      detalle: [
        { codigo: 'PRO-0014', cantidad: 25 },
        { codigo: 'PRO-0015', cantidad: 30 }
      ]
    }
  ];

  for (const venta of ventasEjemplo) {
    const existe = await prisma.venta.findUnique({ where: { codigo: venta.codigo } });
    if (existe) continue;

    let subtotal = 0;
    const detalleConTotales = venta.detalle.map((d) => {
      const prod = productoByCodigo.get(d.codigo);
      const monto = Number(prod.precioVenta) * d.cantidad;
      subtotal += monto;
      return {
        productoId: prod.id,
        cantidad: d.cantidad,
        precioUnitario: prod.precioVenta,
        subtotal: monto
      };
    });

    await prisma.venta.create({
      data: {
        codigo: venta.codigo,
        clienteId: venta.clienteId,
        usuarioId: venta.usuarioId,
        fecha: venta.fecha,
        subtotal,
        descuento: 0,
        total: subtotal,
        estado: 'COMPLETADA',
        detalle: { create: detalleConTotales }
      }
    });
  }
  console.log(`✅ ${ventasEjemplo.length} Ventas de ejemplo con sus detalles procesadas.`);

  console.log('🚀 ¡Seeding de la Papelería completado con total éxito y de forma idempotente!');
}

main()
  .catch((e) => {
    console.error('❌ Error crítico en el proceso de seeding:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
    await pool.end();
  });